<?php
?>
<html>


    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
        <link rel="icon" type="https://logodix.com/logo/8947.png
" href="https://logodix.com/logo/8947.png" />

<title>Allbins PAYPAL @polarqzz</title>

        <link href="toastr.min.css" rel="stylesheet" />
        <link href="style.css" rel="stylesheet" />
        <link rel="stylesheet" href="sweetalert3.css">
     <link href="https://fonts.googleapis.com/css?family=Montserrat:200,300,400,500,600%7CRoboto:400" rel="stylesheet" type="text/css">
    <link href="assets/css/nucleo-icons.css" rel="stylesheet" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

  <!-- CSS Files -->
    <link href="assets/css/black-dashboard.min3f71.css?v=1.1.1" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
    <!-- Head Libs -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
    <script data-pace-options='{ "ajax": false, "selectors": [ "img" ]}' src="https://cdnjs.cloudflare.com/ajax/libs/pace/1.0.2/pace.min.js"></script>
    </head>

  
<body>
    <br><br>
        <div class="row col-md-12">
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
<div class="card col-sm-7">
  <h5 class="card-body h6">Allbins PAYPAL by: @polarqzz</h5>
  <div class="card-body">
<div class="md-form">
    <div class="col-md-12">
  <textarea type="text" style="text-align: center; overflow: hidden;" name="lista" id="lista" placeholder="Linhas em branco ou duplicadas, serão apagadas sozinhas." class="md-textarea form-control" rows="9"></textarea>
</div>
</div><br>


<center>
<font color="white"><b>Em Teste:</b> <b id="nCheckTM" class="badge badge-secondary">Não Iniciado!</b></font>
<br><br>
 <button class="btn btn-info" style="width: 140px; outline: none; font-weight: bold;" id="testar" onClick="startParams()" > INICIAR</button><br><br></center>
<div class="progress">
  <div id="progress_total" class="progress-bar bg-info progress-bar-striped progress-bar-animated" role="progressbar"
  aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width:0%"><center><span id="pct">0</span>%</div></div>

    <div id="progress_live" class="progress-bar bg-success progress-bar-striped progress-bar-animated" role="progressbar"
  aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width:0%"></div>

  </div>
</div>
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
<div class="card col-sm-2">
  <h5 class="card-body h6">INFORMAÇÕES</h5>
  <div class="card-body">
    <font color="white">
<div class="md-form">
<b id="demo">
Status: <span class="badge badge-info">Não Iniciado.</b></span><br><b> 
Carregadas: <span class="badge badge-secondary" id='carregada'>0</span> <br>
Testadas: <span class="badge badge-secondary" id='testado'>0</span> <br>
Aprovadas: <span class="badge badge-success" id='CLIVE'>0</span> <br>
Reprovadas: <span class="badge badge-danger" id='CDIE'>0</span> <br>
Erros: <span class="badge badge-warning" id='CERROS'>0</span><br>
Usuário: <span class="badge badge-dark" id='usuario'>@polarqzz</span><br>
<br>

</b></div></font>
  </div>
</div>
</div>
<br>


<!-- Nav pills -->
<ul class="nav nav-tabs">&nbsp&nbsp
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
<li class="nav-item">
<a class="btn btn-success btn-simple active" data-toggle="pill" href="#aprovadas">Aprovadas</a>
  </li>
  <li class="nav-item">&nbsp&nbsp
    <a class="btn btn-danger btn-simple" data-toggle="pill" href="#reprovadas">Reprovadas</a>
  </li>
  <li class="nav-item">&nbsp&nbsp
    <a class="btn btn-warning btn-simple" data-toggle="pill" href="#erros">Erros</a>
  </li>
</ul>

<!-- Tab panes -->
<div class="tab-content">
  <br>
  <div class="tab-pane container active" id="aprovadas">
<table class="table">
  <tbody>
    <tr>
      <th scope="row">
          <div id="ALLLIVE" style="display: show; font-size: 12px;" onclick="SelectAll('ALLLIVE');"></div>
      </th>
      <td></td>
    </tr>
  </tbody>
</table>
  </div>

  <div class="tab-pane container fade" id="reprovadas">

<table class="table">
  <tbody>
    <tr>
      <th scope="row">
          <div id="ALLDIE" style="display: show; font-size: 12px;" onclick="SelectAll('ALLDIE');"></div>
      </th>
      <td></td>
    </tr>
  </tbody>
</table>
  </div>

  <div class="tab-pane container fade" id="erros">

<table class="table">
  <tbody>
    <tr>
      <th scope="row">
          <div id="ALLERRO" style="display: show; font-size: 12px;" onclick="SelectAll('ALLERRO');"></div>
      </th>
      <td></td>
    </tr>
  </tbody>
</table>
  </div>
</div>
            
        <div id="pgstr"></div>
        </div></div>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.js" type="text/javascript"></script>

<script type="text/javascript">

$(document).ready(function() {
    $("#lista").change(function() {
        cleanIncludeExclude($(this).attr('id'));
    });

});

function cleanIncludeExclude(idToClean) {
    var stringToClean = jQuery.trim($('#' + idToClean).val());

    if (stringToClean.length < 1) {
        return (false);
    }

    stringToClean = stringToClean.replace(/[,]{2,}/g, ',').replace(/%/g, '').replace(/_/g, '').replace(/\r\n|\n|\r/g, ",");

    var tempArr = stringToClean.split(',');
    var uniqueArray = new Array();

    for (var i = 0; i < tempArr.length; i++) {
        tempArr[i] = jQuery.trim(tempArr[i]);

        if (tempArr[i] == '') {
            tempArr.splice(i, 1);
            i--;
        }

        if (uniqueArray[tempArr[i]] != undefined) {
            tempArr.splice(i, 1);
            i--;
        }
        uniqueArray[tempArr[i]] = '';
    }
    $('#' + idToClean).val(tempArr.join('\n'))
}

</script>
            
<script type="text/javascript">
                    
                var clive = document.getElementById('VCL');
                
                // Functions
                function SelectAll(id)
                {
                    document.getElementById(id).focus();
                    document.getElementById(id).select();
                }
                
                function cvcl(){
                    if(clive.checked == false){
                        document.getElementById("emLIVE").style.display = "block";
                        document.getElementById("nLive").style.display = "block";
                    } else if(clive.checked == true){
                        document.getElementById("emLIVE").style.display = "none";
                        document.getElementById("nLive").style.display = "none";
                    } 
                }
                
                function startchk(url, chard, pchk){

                    var xmlhttp;
                    if (window.XMLHttpRequest)
                    {
                        xmlhttp=new XMLHttpRequest();
                    }
                    else
                    {
                        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
                    }
                    xmlhttp.onreadystatechange=function()
                    {
                        if (xmlhttp.readyState==4 && xmlhttp.status==200)
                        {
                            var xdata = xmlhttp.responseText;
                            var totaltestado = document.getElementById("testado")
                            var totalcarregado = document.getElementById("carregada").innerHTML;;
                            var naosei = totaltestado.innerHTML = (eval(totaltestado.innerHTML) + 1);
                            var naosesi = (eval(document.getElementById("testado").innerHTML) + 1);
                            var countlive = (eval(document.getElementById("CLIVE").innerHTML) + 1);
                            var countlixo = (eval(document.getElementById("CDIE").innerHTML) + 1);
                            var counterros = (eval(document.getElementById("CERROS").innerHTML) + 1);
                            var resultado = Math.floor((naosei / chard) * 100);

                            document.getElementById("nCheckTM").innerHTML = "" +  url + "";
                            document.getElementById("pct").innerHTML = + resultado + "";
                            document.getElementById("progress_total").style.width = resultado + "%";
                            document.title = "[" + naosei + "/" + totalcarregado + "] - " + resultado + "%" + "";

                            if (xdata.match(/class="badge badge-success">LIVE/g)) {
                                document.getElementById("demo").innerHTML = 'Status: <span class="badge badge-success">Aprovada!</span>';
                                removelinha();
                                document.getElementById("CLIVE").innerHTML = countlive;
                                document.getElementById("ALLLIVE").innerHTML = document.getElementById("ALLLIVE").innerHTML +  xdata + " \n";
                                audiolive.play();

                            } else if (xdata.match(/class="badge badge-danger">DIE/g)) {
                             document.getElementById("demo").innerHTML = 'Status: <span class="badge badge-danger">Reprovada!</span>';
                            removelinha();
                                document.getElementById("CDIE").innerHTML = countlixo;
                                document.getElementById("ALLDIE").innerHTML = document.getElementById("ALLDIE").innerHTML +  xdata + " \n"
                            }
                            else{
                            document.getElementById("demo").innerHTML = 'Status: <span class="badge badge-warning">Erro!</span>';
                            removelinha();
                                document.getElementById("CERROS").innerHTML = counterros;
                                document.getElementById("ALLERRO").innerHTML = document.getElementById("ALLERRO").innerHTML +  xdata + " \n"
                            }

                         if (resultado == 100){
                            setTimeout(function() {
                            swal('FINALIZADO!' , 'LISTA TESTADA COM SUCESSO.' , 'success');
                            audiofim.play();
                            document.getElementById("demo").innerHTML = 'Status: <span class="badge badge-info">Finalizado!</span>';
                            },);}

                            if (resultado == 100){
                            setTimeout(function() {
                            document.getElementById("nCheckTM").innerHTML = "Lista Finalizada!";
                            },);}
                        }
                    }
                    xmlhttp.open("GET","/api.php?lista=" + url,true);
                    xmlhttp.send();
                }

                var audioinicio = new Audio('inicio.mp3');
                var audiofim = new Audio('fim.mp3');
                var audiolive = new Audio('live.ogg');

                function listToArray(fullString, separator) {
                    var fullArray = [];
                    
                    if (fullString !== undefined) {
                        if (fullString.indexOf(separator) == 0) {
                            fullAray.push(fullString);
                        } else {
                            fullArray = fullString.split(separator);
                        }
                    }
                    
                    return fullArray;
                }
                function count(mixed_var, mode) {
                    var key, cnt = 0;
                    if (mixed_var === null || typeof mixed_var === 'undefined') {
                        return 0;
                    } else if (mixed_var.constructor !== Array && mixed_var.constructor !== Object) {
                        return 1;
                    }
                    if (mode === 'COUNT_RECURSIVE') {
                        mode = 1;
                    }
                    if (mode != 1) {
                        mode = 0;
                    }
                    for (key in mixed_var) {
                        if (mixed_var.hasOwnProperty(key)) {
                            cnt++;
                            if (mode == 1 && mixed_var[key] && (mixed_var[key].constructor === Array || mixed_var[key].constructor ===
                                                                Object)) {
                                cnt += this.count(mixed_var[key], 1);
                            }
                        }
                    }
                    return cnt;
                }
                function pushcsB(c,p) {
                    document.getElementById(p).innerHTML = document.getElementById(p).innerHTML + c + "\n<br>" ;
                }

                function removelinha() {
                var lines = $("#lista").val().split('\n');
                lines.splice(0, 1);
                $("#lista").val(lines.join("\n"));
                }

                function startParams() {
                    if($("#lista").val()== null || $("#lista").val() == ""){
                    toastr.badge-warning('SUA LISTA ESTÁ VAZIA.', 'ATENÇÃO!', {timeOut: 3000, positionClass: 'toast-top-right'});
                    return false;
                    }
                    else{
                    document.getElementById("pgstr").style.display = "block";
                    var textarea = document.getElementById("lista").value;
                    // var textareacount = textarea.split("\n");
                    var textareacount = textarea.split('\n');
                    var textareaMatch = count(textareacount, 'COUNT_RECURSIVE');
                    //Check
                    var myString = textarea;
                    var myArray = listToArray(myString, '\n');
                   
                    document.getElementById("demo").innerHTML = '';
                    document.getElementById("carregada").innerHTML = textareaMatch;   
                    for(var i=0;i<textareaMatch;i++){
                        
                        var cclst = myArray[i];
                        var cemail = cclst.split("|");
                        var csids = 'csid_' + i;
                        var ccids = 'ccid_' + i;
                        
                        var output = document.getElementById("lista").value;
                        output = output.replace(cclst, "");
                        output = output.replace("\n", "");
                        document.getElementById("lista").innerHTML = output;
                        startchk(cclst, textareaMatch, i);
                        
                    }
                    audioinicio.play();    
                    toastr.success('CHECKER INICIADO.', 'SUCESSO!', {timeOut: 3000, positionClass: 'toast-top-right'});
                    document.getElementById("demo").innerHTML = 'Status: <span class="badge badge-info">Iniciado!</span>';
                    }
                   
                    
                }

                
            </script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0/jquery.js" data-semver="3.0.0" data-require="jquery"></script>
            <script src="sweetalert2.js"></script>
                <script src="toastr.min.js"></script>
                <script src="script.js"></script> 
        </center>
    </body>
</html>
